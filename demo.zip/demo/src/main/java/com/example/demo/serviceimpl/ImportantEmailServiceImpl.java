package com.example.demo.serviceimpl;



import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.example.demo.dao.ImportantEmailRepository;

import com.example.demo.dto.ImportantEmailDto;
import com.example.demo.dto.ResponseDto;
import com.example.demo.entity.ImportantEmailEntity;

import com.example.demo.service.ImportantEmailService;

import lombok.Data;
@Service
@Data
public class ImportantEmailServiceImpl implements ImportantEmailService{
	private final ImportantEmailRepository importantEmailRepository;
	

	@Override
	public ResponseDto addImportantEmail(ImportantEmailDto importantEmailDto) {
		ResponseDto response=new ResponseDto();

		ImportantEmailEntity importantEmail=new ImportantEmailEntity();
		
		try {

				importantEmail.setEntityId(importantEmailDto.getEntityId());
				importantEmail.setCcEmailId(importantEmailDto.getCcEmailId());
				importantEmail.setDueDate(importantEmailDto.getDueDate());
				importantEmail.setEmailType(importantEmailDto.getEmailType());
				importantEmail.setFromEmailId(importantEmailDto.getFromEmailId());
				importantEmail.setMailBody(importantEmailDto.getMailBody());
				importantEmail.setMailSub(importantEmailDto.getMailSub());
				importantEmail.setMessageId(importantEmailDto.getMessageId());
				importantEmail.setReceivedDate(importantEmailDto.getReceivedDate());
				importantEmail.setRemarks(importantEmailDto.getRemarks());
				importantEmail.setToEmailId(importantEmailDto.getToEmailId());
				importantEmail.setThreadId(importantEmailDto.getThreadId());
				importantEmail.setImportantEmailStatus(importantEmailDto.getImportantEmailStatus());
                          if(importantEmailDto.getThreadId()==importantEmailDto.getMessageId()) {
                	 if(importantEmailRepository.existsByThreadId(importantEmailDto.getThreadId()) && importantEmailRepository.existsByMessageId(importantEmailDto.getMessageId()) ){
                		 response.setMessage("MessageId and ThreadId value not valid ");
                    				 response.setStatus(201);
                	 }
                	 else {
                		 if(importantEmailDto.getEmailType().equalsIgnoreCase("inbound")||importantEmailDto.getEmailType().equalsIgnoreCase("bound")) {
                			 if(importantEmailDto.getImportantEmailStatus().equalsIgnoreCase("open") || importantEmailDto.getImportantEmailStatus().equalsIgnoreCase("closed"))
                			 { response.setMessage("Added Sucessfully");
        				 response.setStatus(200);
        				 importantEmailRepository.save(importantEmail);}
                			 else {
                				 response.setMessage("ImportantEmailStatus must be 'open' or 'close' ");
                				 response.setStatus(201);
                			 }
                	 }
                		 else {
                			 response.setMessage("EmailType must be 'inbound' or 'outbound' ");
            				 response.setStatus(201);
                		 }
                		 
                		 }
                	 
                          }
                 else {
                	// System.out.println((importantEmailRepository.existsByThreadIdAndMessageId(importantEmailDto.getThreadId(),importantEmailDto.getMessageId())));
                	 if((importantEmailRepository.existsByThreadIdAndMessageId(importantEmailDto.getThreadId(),importantEmailDto.getMessageId()))){ 
                		 response.setMessage("MessageId and ThreadId value not valid ");
        				 response.setStatus(201);
                	 }
                	 else {
                	 if(importantEmailDto.getEmailType().equalsIgnoreCase("inbound")||importantEmailDto.getEmailType().equalsIgnoreCase("outbound")) {
            			 if(importantEmailDto.getImportantEmailStatus().equalsIgnoreCase("open") || importantEmailDto.getImportantEmailStatus().equalsIgnoreCase("closed"))
            			 { response.setMessage("Added Sucessfully");
    				 response.setStatus(200);
    				 importantEmailRepository.save(importantEmail);}
            			 else {
            				 response.setMessage("ImportantEmailStatus must be 'open' or 'close' ");
            				 response.setStatus(201);
            			 }
            	 }
            		 else {
            			 response.setMessage("EmailType must be 'inbound' or 'outbound' ");
        				 response.setStatus(201);
            		 }
                	 }
                 }
                
			
		}
		   
		
		catch(Exception e) {
			throw e;
		}
		return response;
	}
	@Override
	public List<ImportantEmailDto> getByEntityId(String entityId,String emailType) {
		// TODO Auto-generated method stub
		List<ImportantEmailEntity> importantEmailDtoList=importantEmailRepository.findByEntityId(entityId, emailType);
		try {
		
			 return importantEmailDtoList.
		stream()
		.map(val->{
			ImportantEmailDto importantEmailDto=new ImportantEmailDto();
			
			importantEmailDto.setImportantEmailId(val.getImportantEmailId());
			importantEmailDto.setEntityId(val.getEntityId());
			importantEmailDto.setFromEmailId(val.getFromEmailId());
			importantEmailDto.setToEmailId(val.getToEmailId());
			importantEmailDto.setCcEmailId(val.getCcEmailId());
			importantEmailDto.setMailSub(val.getMailSub());
			importantEmailDto.setMailBody(val.getMailBody());
			importantEmailDto.setReceivedDate(val.getReceivedDate());
			importantEmailDto.setEmailType(val.getEmailType());
			importantEmailDto.setDueDate(val.getDueDate());
			importantEmailDto.setImportantEmailStatus(val.getImportantEmailStatus());
			importantEmailDto.setRemarks(val.getRemarks());
			importantEmailDto.setThreadId(val.getThreadId());
			importantEmailDto.setMessageId(val.getMessageId());
			return importantEmailDto;
//			importantEmailDtoList.add(importantEmailDto);
			
		}).collect(Collectors.toList());
		}
		catch(Exception e) {
			throw e;
		}
		
	}
	@Override
	public ImportantEmailDto getByEntityId(int threadId, int messageId) {
		ImportantEmailDto importantEmailDto=new ImportantEmailDto();
		ImportantEmailEntity importantEmail=new ImportantEmailEntity();
try {
	     Optional<ImportantEmailEntity> importantEmailEntityOpn=importantEmailRepository.findByThreadIdAndMessageId(threadId,messageId);
	 if( importantEmailEntityOpn.isPresent()) {
		 importantEmail=importantEmailEntityOpn.get();
		 importantEmailDto.setImportantEmailId( importantEmail.getImportantEmailId());
		 importantEmailDto.setEntityId( importantEmail.getEntityId());
		 importantEmailDto.setFromEmailId( importantEmail.getFromEmailId());
		 importantEmailDto.setEntityId(importantEmailDto.getEntityId());
		 importantEmailDto.setToEmailId(importantEmail.getToEmailId());
		 importantEmailDto.setCcEmailId( importantEmail.getCcEmailId());
		 importantEmailDto.setMailSub( importantEmail.getMailSub());
		 importantEmailDto.setMailBody( importantEmail.getMailBody());
		 importantEmailDto.setReceivedDate( importantEmail.getReceivedDate());
		 importantEmailDto.setEmailType( importantEmail.getEmailType());
		 importantEmailDto.setDueDate( importantEmail.getDueDate());
		 importantEmailDto.setImportantEmailStatus( importantEmail.getImportantEmailStatus());
		 importantEmailDto.setRemarks( importantEmail.getRemarks());
		 importantEmailDto.setThreadId( importantEmail.getThreadId());
		 importantEmailDto.setMessageId( importantEmail.getMessageId());
	 }
	
}
catch(Exception e) {
	throw e;
}
		return  importantEmailDto ;
	}
	@Override
	public ImportantEmailDto getById(String importantEmailId) {

		ImportantEmailDto importantEmailDto=new ImportantEmailDto();
		ImportantEmailEntity importantEmail=new ImportantEmailEntity();
		try {
		  Optional<ImportantEmailEntity> importantEmailOption=importantEmailRepository.findById(importantEmailId);
		  if(importantEmailOption.isPresent()) {
			  importantEmail=importantEmailOption.get();
			  importantEmailDto.setImportantEmailId( importantEmail.getImportantEmailId());
				 importantEmailDto.setEntityId( importantEmail.getEntityId());
				 importantEmailDto.setFromEmailId( importantEmail.getFromEmailId());
				 importantEmailDto.setEntityId(importantEmailDto.getEntityId());
				 importantEmailDto.setToEmailId(importantEmail.getToEmailId());
				 importantEmailDto.setCcEmailId( importantEmail.getCcEmailId());
				 importantEmailDto.setMailSub( importantEmail.getMailSub());
				 importantEmailDto.setMailBody( importantEmail.getMailBody());
				 importantEmailDto.setReceivedDate( importantEmail.getReceivedDate());
				 importantEmailDto.setEmailType( importantEmail.getEmailType());
				 importantEmailDto.setDueDate( importantEmail.getDueDate());
				 importantEmailDto.setImportantEmailStatus( importantEmail.getImportantEmailStatus());
				 importantEmailDto.setRemarks( importantEmail.getRemarks());
				 importantEmailDto.setThreadId( importantEmail.getThreadId());
				 importantEmailDto.setMessageId( importantEmail.getMessageId());
			  
		  }}
		catch(Exception e) {
			throw e;
		}
		  
		
		return importantEmailDto;
	}
	

}
