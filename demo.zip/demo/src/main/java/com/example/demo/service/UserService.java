package com.example.demo.service;

import com.example.demo.dto.ResponseDto;
import com.example.demo.dto.UserDto;

public interface UserService {

	ResponseDto addUser(UserDto userDto);

}
