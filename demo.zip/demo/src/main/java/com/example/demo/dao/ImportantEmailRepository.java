package com.example.demo.dao;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.entity.ImportantEmailEntity;

public interface ImportantEmailRepository  extends JpaRepository<ImportantEmailEntity,String> {

	boolean existsByThreadId(int threadId);


	boolean existsByMessageId(int messageId);


	boolean existsByThreadIdAndMessageId(int threadId, int messageId);

  @Query(value="SELECT * FROM important_email_table WHERE entity_id=:entityId AND (:emailType IS NULL OR email_type=:emailType)",nativeQuery=true)
	ArrayList<ImportantEmailEntity> findByEntityId(@Param("entityId")String entityId,@Param("emailType") String emailType);

@Query(value="SELECT * FROM important_email_table WHERE thread_id=:threadId AND message_id=:messageId",nativeQuery=true)
Optional<ImportantEmailEntity> findByThreadIdAndMessageId(int threadId, int messageId);
	

}
