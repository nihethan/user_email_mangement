package com.example.demo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.UserEntityTableEntity;

public interface UserEntityTableRepository extends JpaRepository<UserEntityTableEntity,String> {

	List<UserEntityTableEntity> findByUserId(String userId);
 
//	@Query(value="SELECT ue FROM UserEntity ue ")
	

	

}
