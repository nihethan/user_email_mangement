package com.example.demo.dto;

import lombok.Data;

@Data
public class ResponseDto {
  private String message;
  private int status;
}
