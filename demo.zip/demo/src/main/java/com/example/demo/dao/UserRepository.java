package com.example.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.UserEntity;

public interface UserRepository  extends JpaRepository<UserEntity,String>{
	
  boolean existsByEmail(String email);

boolean existsByUserId(String userId);
}
