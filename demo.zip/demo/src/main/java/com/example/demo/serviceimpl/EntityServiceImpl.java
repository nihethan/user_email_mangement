package com.example.demo.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.example.demo.dao.EntityRepository;
import com.example.demo.dao.UserEntityTableRepository;
import com.example.demo.dao.UserRepository;
import com.example.demo.dto.EntityDto;
import com.example.demo.dto.ResponseDto;
import com.example.demo.entity.EntityTableEntity;
import com.example.demo.entity.UserEntityTableEntity;
import com.example.demo.service.EntityService;

import lombok.Data;

@Service
@Data
public class EntityServiceImpl implements EntityService {
	private final EntityRepository entityRepository;
	private final UserRepository userRepository;
	private final UserEntityTableRepository userEntityTableRepository;

	@Override
	public ResponseDto addEntity(EntityDto entityDto) {
		// System.out.println(entityDto);
		ResponseDto response = new ResponseDto();
		EntityTableEntity entitytable = new EntityTableEntity();
		UserEntityTableEntity userEntityTableEntity=new UserEntityTableEntity();
		try {
			if (entityDto.getEntityId() != null) {
				Optional<EntityTableEntity> entityopt = entityRepository.findById(entityDto.getEntityId());
				if (entityopt.isPresent()) {
					entitytable = entityopt.get();
					entitytable.setEntityId(entityDto.getEntityId());
					entitytable.setEntityName(entityDto.getEntityName());
					entitytable.setUserId(entityDto.getUserId());
					entitytable.setEntityStatus(entityDto.getEntityStatus());
					if (entityRepository.existsByEntityName(entityDto.getEntityName())) {
						response.setMessage("Entity Name Already Exists");
						response.setStatus(201);
					}

					else if ((userRepository.existsByUserId(entityDto.getUserId()))) {
						if ((entityDto.getEntityStatus().equalsIgnoreCase("Active"))
								|| (entityDto.getEntityStatus().equalsIgnoreCase("InActive"))) {
							response.setMessage("Updated Sucessfully");
							response.setStatus(200);
							entityRepository.save(entitytable);
						} else {
							response.setMessage("EntityStatus Must Be 'Active' or 'InActive'");
							response.setStatus(201);
						}

					}

					else {
						response.setMessage("User Id Not Exisit in UserTable ");
						response.setStatus(201);
					}
				}
			} else {

				entitytable.setEntityName(entityDto.getEntityName());
				entitytable.setUserId(entityDto.getUserId());

				entitytable.setEntityStatus(entityDto.getEntityStatus());
				// System.out.println(entityDto.getEntityStatus());
				if (entityRepository.existsByEntityName(entityDto.getEntityName())) {
					response.setMessage("Entity Name Already Exists");
					response.setStatus(201);
				}

				else if ((userRepository.existsByUserId(entityDto.getUserId()))) {
					if ((entityDto.getEntityStatus().equalsIgnoreCase("Active"))
							|| (entityDto.getEntityStatus().equalsIgnoreCase("InActive"))) {
						response.setMessage("Added Sucessfully");
						response.setStatus(200);
						entityRepository.save(entitytable);
						userEntityTableEntity.setEntityId(entityRepository.save(entitytable));
						userEntityTableEntity.setUserId(entityDto.getUserId());
						response.setMessage("Added Details Sucessfully in User Entity Table");
						response.setStatus(200);
						userEntityTableRepository.save(userEntityTableEntity);
						
						
					} 
					else {
						response.setMessage("EntityStatus Must Be 'Active' or 'InActive'");
						response.setStatus(201);
					}

				}

				else {
					response.setMessage("User Id Not Exisit in UserTable ");
					response.setStatus(201);
				}
			}

		} catch (Exception e) {
			throw e;
		}
		return response;

	}

	@Override
	public List<EntityDto> getListOfEntityByUserId(String userId) {

		List<EntityDto> entityDtoList = new ArrayList<>();

			try {
				entityDtoList=	entityRepository.findByUserId(userId)
			.stream()
			.map(val -> {

			EntityDto entityDto = new EntityDto();
			entityDto.setUserId(val.getUserId());
			entityDto.setEntityId(val.getEntityId());
			entityDto.setEntityName(val.getEntityName());
			entityDto.setEntityStatus(val.getEntityStatus());
			
				return entityDto;
			}).collect(Collectors.toList());
				}
			catch(Exception e) {
				throw e;
			}
		
			return entityDtoList;
	
	}

}
