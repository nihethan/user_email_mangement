package com.example.demo.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.ImportantEmailDto;
import com.example.demo.dto.ResponseDto;
import com.example.demo.service.ImportantEmailService;

import lombok.Data;

@RestController
@RequestMapping
@Data
public class ImportantEmailController {
	private final ImportantEmailService importantEmailService;
	@PostMapping("/importantemail")
	public ResponseEntity<ResponseDto> addImportantEmail(@RequestBody ImportantEmailDto importantEmailDto){
		return ResponseEntity.ok( importantEmailService.addImportantEmail(importantEmailDto));
	}
	
	@GetMapping("/importantemail")
	public ResponseEntity<List<ImportantEmailDto>> getByEntityId(@RequestParam("entityId") String entityId,@RequestParam(required=false) String emailType){
		return ResponseEntity.ok(importantEmailService.getByEntityId(entityId,emailType));
	}
	@GetMapping("/importantbytimi")
	public ResponseEntity<ImportantEmailDto> getByThreadIdAndMessageId(@RequestParam("threadId") int threadId,@RequestParam("messageId") int messageId) {
		return ResponseEntity.ok(importantEmailService.getByEntityId(threadId,messageId));
	}
	
	@GetMapping("/importantemailbyid")
	public ResponseEntity<ImportantEmailDto> getById(@RequestParam("importantEmailId") String importantEmailId){
		return ResponseEntity.ok(importantEmailService.getById(importantEmailId));
	}

}
