package com.example.demo.dto;

import java.time.LocalDate;

import lombok.Data;

@Data
public class ImportantEmailDto {
  private String importantEmailId;
  private String entityId;
  private String fromEmailId;
  private String toEmailId;
  private String ccEmailId;
  private String mailSub;
  private String mailBody;
  private LocalDate receivedDate;
  private String emailType;
  private String dueDate;
  private String importantEmailStatus;
  private String remarks;
  private int threadId;
  private int messageId;
  
  
}
