package com.example.demo.dto;

import jakarta.persistence.Column;
import lombok.Data;

@Data
public class UserEntityDto {
	  private String userEntityId; 
	   private EntityDto entityId;
	   private String userId;
}
