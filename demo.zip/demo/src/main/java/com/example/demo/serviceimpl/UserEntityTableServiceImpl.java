package com.example.demo.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.example.demo.dao.UserEntityTableRepository;
import com.example.demo.dto.EntityDto;
import com.example.demo.dto.UserEntityDto;
import com.example.demo.entity.EntityTableEntity;
import com.example.demo.entity.UserEntityTableEntity;
import com.example.demo.service.UserEntityTableService;

import lombok.Data;
@Service
@Data
public class UserEntityTableServiceImpl implements UserEntityTableService{
     public final UserEntityTableRepository userEntityTableRepository;
	@Override
	public List<UserEntityDto> getDetailsByUserId(String userId) {

		//List<UserEntityDto> userEntityDtoList=new ArrayList<>();
		List<UserEntityTableEntity> userEntityTableList=userEntityTableRepository.findByUserId(userId);
		try {
			return 	userEntityTableList.stream().map(ue->{
				EntityTableEntity entityTable=ue.getEntityId();
		EntityDto entityDto=new EntityDto();
				entityDto.setEntityId(entityTable.getEntityId());
				entityDto.setEntityName(entityTable.getEntityName());
				entityDto.setEntityStatus(entityTable.getEntityStatus());
				entityDto.setUserId(entityTable.getUserId());
				
				UserEntityDto userEntityDto=new UserEntityDto();
				userEntityDto.setUserEntityId(ue.getUserEntityId());
				userEntityDto.setEntityId(entityDto);
				userEntityDto.setUserId(ue.getUserId());
				return userEntityDto;

			})	.collect(Collectors.toList());
	
		}		
		catch(Exception e) {
			throw e;
			
		}
		
	}

}
