package com.example.demo.dto;

import lombok.Data;

@Data
public class UserDto {
  private String userId;
  private String email;
  private String password;
  private String userName;
  
}
