package com.example.demo.entity;

import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name="entity_table")
public class EntityTableEntity {
@Id
@UuidGenerator
@Column(name="entity_id")
	private String entityId;
@Column(name="entity_name")
	private String entityName;
@Column(name="user_id")
	private String userId;
@Column(name="status")
	private String entityStatus;
}
