package com.example.demo.entity;

import java.time.LocalDate;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
@Entity
@Data
@Table(name="important_email_table")
public class ImportantEmailEntity {
	@Id
	@UuidGenerator
	@Column(name="important_email_id")
	 private String importantEmailId;
	@Column(name="entity_id")
	  private String entityId;
	@Column(name="from_mail_id")
	  private String fromEmailId;
	@Column(name="to_mail_id")
	  private String toEmailId;
	@Column(name="cc_mail_id")
	  private String ccEmailId;
	@Column(name="mail_sub")
	  private String mailSub;
	@Column(name=" mail_body")
	  private String mailBody;
	@CreationTimestamp
	@Column(name="received_date")
	  private LocalDate receivedDate;
	@Column(name=" email_type")
	  private String emailType;
	@Column(name="due_date")
	  private String dueDate;
	@Column(name=" status")
	  private String importantEmailStatus;
	@Column(name=" remarks")
	  private String remarks;
	@Column(name="thread_id")
	  private int threadId;
	@Column(name="message_id")
	  private int messageId;
	  
}
