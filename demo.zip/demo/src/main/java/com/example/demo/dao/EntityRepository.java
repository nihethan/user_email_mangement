package com.example.demo.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.entity.EntityTableEntity;

public interface EntityRepository  extends JpaRepository<EntityTableEntity,String>  {

	boolean existsByEntityName(String entityName);
    
	@Query(value="SELECT * FROM entity_table WHERE user_id=:userId AND status=Active",nativeQuery=true)
	public List<EntityTableEntity> findByUserId(@Param("userId")String userId );
	
	
 
}
