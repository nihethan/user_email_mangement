package com.example.demo.serviceimpl;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.demo.dao.UserRepository;
import com.example.demo.dto.ResponseDto;
import com.example.demo.dto.UserDto;
import com.example.demo.entity.UserEntity;
import com.example.demo.service.UserService;

import lombok.Data;
@Service
@Data
public class UserServiceImpl implements UserService{
       private final UserRepository userRepository;
	@Override
	public ResponseDto addUser(UserDto userDto) {
		//System.out.print(userDto);
		ResponseDto response=new ResponseDto();
		UserEntity user=new UserEntity();
		try {	
			if(userDto.getUserId()!=null) {
				Optional<UserEntity> useropt=userRepository.findById(userDto.getUserId());
				if(useropt.isPresent()) {
					user=useropt.get();
				//	System.out.print(userDto.getUserId());
				user.setUserId(userDto.getUserId());
				user.setEmail(userDto.getEmail());
				user.setPassword(userDto.getPassword());
				user.setUserName(userDto.getUserName());
				 response.setMessage("Updated Sucessfully");
				 response.setStatus(200);
				 userRepository.save(user);
			}
				
				}
			else {
				user.setEmail(userDto.getEmail());
			//	System.out.print(userDto.getEmail());
				user.setPassword(userDto.getPassword());
				user.setUserName(userDto.getUserName());
				if(userRepository.existsByEmail(userDto.getEmail())) {
					response.setMessage("Email Id Already Exists");
					response.setStatus(201);
				}
				else {
				 response.setMessage("Added Sucessfully");
				 response.setStatus(200);
				 userRepository.save(user);
				}
			
			
		} 
				
		}
		catch(Exception e) {
			response.setMessage("Failed to save");
			throw e;
		}
		return response;
	}
	

}
