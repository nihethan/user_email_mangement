package com.example.demo.service;

import java.util.List;

import com.example.demo.dto.EntityDto;
import com.example.demo.dto.ResponseDto;

public interface EntityService {

	ResponseDto addEntity(EntityDto entityDto);

    List<EntityDto> getListOfEntityByUserId(String userId);

	

}
