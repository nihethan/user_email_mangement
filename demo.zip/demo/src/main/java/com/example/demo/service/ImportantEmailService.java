package com.example.demo.service;

import java.util.List;

import com.example.demo.dto.ImportantEmailDto;
import com.example.demo.dto.ResponseDto;

public interface ImportantEmailService {

	ResponseDto addImportantEmail(ImportantEmailDto importantEmailDto);

	List<ImportantEmailDto> getByEntityId(String entityId,String emailType);

	ImportantEmailDto getByEntityId(int threadId, int messageId);

	ImportantEmailDto getById(String importantEmailId);

}
