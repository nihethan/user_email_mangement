package com.example.demo.service;

import java.util.List;

import com.example.demo.dto.UserEntityDto;

public interface UserEntityTableService {

	List<UserEntityDto> getDetailsByUserId(String userId);

}
