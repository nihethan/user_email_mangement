package com.example.demo.entity;

import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name="user_entity_table")
@Data
public class UserEntityTableEntity {
   @Id
   @Column(name="user_entity_id")
   @UuidGenerator
   private String userEntityId;
   @ManyToOne
   @JoinColumn(name="entity_id",referencedColumnName="entity_id")

   private EntityTableEntity entityId;
   @Column(name="user_id")
   private String userId;
   
}
