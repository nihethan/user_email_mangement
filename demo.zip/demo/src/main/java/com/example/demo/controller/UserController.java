package com.example.demo.controller;



import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.UserRepository;
import com.example.demo.dto.ResponseDto;
import com.example.demo.dto.UserDto;
import com.example.demo.service.UserService;

import lombok.Data;

@RestController
@RequestMapping
@Data
public class UserController {
  private final UserService userService;
  private final UserRepository userRepository;
  @PostMapping("user")
  public ResponseEntity<ResponseDto> addUser(@RequestBody UserDto userDto){

	  return ResponseEntity.ok(userService.addUser(userDto));
  }
 
}
