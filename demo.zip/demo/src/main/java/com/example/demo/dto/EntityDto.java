package com.example.demo.dto;

import lombok.Data;

@Data
public class EntityDto {
	private String entityId;
	private String entityName;
	private String userId;
	private String entityStatus;

}
