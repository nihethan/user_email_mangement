package com.example.demo.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.EntityDto;
import com.example.demo.dto.ResponseDto;
import com.example.demo.service.EntityService;

import lombok.Data;

@RestController
@RequestMapping
@Data
public class EntityController {
    private final EntityService entityService;
    
    @PostMapping("entity")
    public  ResponseEntity<ResponseDto>addEntity(@RequestBody EntityDto entityDto) {
		return  ResponseEntity.ok(entityService.addEntity(entityDto));
    }
    @GetMapping("entity")
    public ResponseEntity<List<EntityDto>> getListOfEntityByUserId(@RequestParam("userId") String userId){
    	return ResponseEntity.ok(entityService.getListOfEntityByUserId(userId));
    }
}
