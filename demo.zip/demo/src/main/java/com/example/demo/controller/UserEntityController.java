package com.example.demo.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.UserEntityTableRepository;
import com.example.demo.dto.UserEntityDto;
import com.example.demo.entity.UserEntityTableEntity;
import com.example.demo.service.UserEntityTableService;

import lombok.Data;

@RestController
@RequestMapping
@Data
public class UserEntityController {
	private final UserEntityTableService userEntityTableService;
	@GetMapping("userentity")
	public ResponseEntity<List<UserEntityDto>> getDetailsByUserId(@RequestParam("userId") String userId){
		return ResponseEntity.ok(userEntityTableService.getDetailsByUserId(userId));
	}
     
}
